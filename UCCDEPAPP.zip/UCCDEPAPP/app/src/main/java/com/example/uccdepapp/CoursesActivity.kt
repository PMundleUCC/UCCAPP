package com.example.uccdepapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CoursesActivity : ComponentActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var courseList: ArrayList<Course>
    private lateinit var courseAdapter: CourseAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_courses)

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)


        // Initialize the ArrayList and Adapter
        courseList = ArrayList()
        courseAdapter = CourseAdapter(courseList)
        recyclerView.adapter = courseAdapter

        // Initialize the Firebase Database reference
        database = FirebaseDatabase.getInstance().getReference("Course")

        // Fetch the courses from the database
        fetchCourses()

    }

    private fun fetchCourses() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                courseList.clear()
                for (courseSnapshot in snapshot.children) {
                    val course = courseSnapshot.getValue(Course::class.java)
                    if (course != null) {
                        courseList.add(course)
                    }
                }
                courseAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Failed to load Course data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
