package com.example.uccdepapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.TextView

class AdmissionsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admissions)

        val admissionInfo = findViewById<TextView>(R.id.admission_info)
        admissionInfo.text = "Click Apply now for admission requirements for the IT Department..."

        val applicationLink = findViewById<TextView>(R.id.application_link)
        applicationLink.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ucc.edu.jm/apply"))
            startActivity(intent)
        }
    }
}
