package com.example.uccdepapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView


class TimetableAdapter : ListAdapter<TimetableEntry, TimetableAdapter.TimetableViewHolder>(TimetableDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimetableViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_timetable, parent, false)
        return TimetableViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimetableViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    class TimetableViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val yearTextView: TextView = itemView.findViewById(R.id.yearTextView)
        private val termTextView: TextView = itemView.findViewById(R.id.termTextView)
        private val classStartTimeTextView: TextView = itemView.findViewById(R.id.classStartTimeTextView)
        private val levelTextView: TextView = itemView.findViewById(R.id.levelTextView)
        private val courseTextView: TextView = itemView.findViewById(R.id.courseTextView)
        private val registrationPeriodTextView: TextView = itemView.findViewById(R.id.registrationPeriodTextView)

        fun bind(item: TimetableEntry) {
            yearTextView.text = item.year.toString()
            termTextView.text = item.term
            classStartTimeTextView.text = item.classStartTime
            levelTextView.text = item.level.toString()
            courseTextView.text = item.course
            registrationPeriodTextView.text = item.registrationPeriod
        }
    }

    class TimetableDiffCallback : DiffUtil.ItemCallback<TimetableEntry>() {
        override fun areItemsTheSame(oldItem: TimetableEntry, newItem: TimetableEntry): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: TimetableEntry, newItem: TimetableEntry): Boolean {
            return oldItem == newItem
        }
    }
}
