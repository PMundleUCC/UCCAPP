package com.example.uccdepapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.ComponentActivity

class SocialMediaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_social_media)

        // Initialize the social media buttons
        val facebookIcon: ImageButton = findViewById(R.id.facebook_button)
        val twitterIcon: ImageButton = findViewById(R.id.twitter_button)
        val instagramIcon: ImageButton = findViewById(R.id.instagram_button)
        val linkedinIcon: ImageButton = findViewById(R.id.linkedin_button)
        val youtubeIcon: ImageButton = findViewById(R.id.youtube_button)

        // Set click listeners to open URLs
        facebookIcon.setOnClickListener {
            openUrl("https://www.facebook.com/uccjamaica")
        }

        twitterIcon.setOnClickListener {
            openUrl("http://www.twitter.com/uccjamaica")
        }

        instagramIcon.setOnClickListener {
            openUrl("http://www.instagram.com/uccjamaica")
        }

        linkedinIcon.setOnClickListener {
            openUrl("http://www.linkedin.com/company/uccjamaica")
        }
        youtubeIcon.setOnClickListener {
            openUrl("http://www.youtube.com/user/uccjamaica")
        }
    }


    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        startActivity(intent)
    }
}
