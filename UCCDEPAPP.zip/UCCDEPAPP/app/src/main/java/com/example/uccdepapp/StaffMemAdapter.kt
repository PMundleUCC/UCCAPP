package com.example.uccdepapp

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class FacultyStaffMemberAdapter(private val memberList: List<FacultyStaffMember>) :
    RecyclerView.Adapter<FacultyStaffMemberAdapter.FacultyStaffMemberViewHolder>() {

    class FacultyStaffMemberViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val photo: ImageView = itemView.findViewById(R.id.photo)
        val name: TextView = itemView.findViewById(R.id.name)
        val telephone: TextView = itemView.findViewById(R.id.telephone)
        val email: TextView = itemView.findViewById(R.id.email)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FacultyStaffMemberViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.directory_item, parent, false)
        return FacultyStaffMemberViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FacultyStaffMemberViewHolder, position: Int) {
        val currentMember = memberList[position]

       Picasso.get().load(currentMember.photoUrl).into(holder.photo)
        holder.name.text = currentMember.name
        holder.telephone.text = currentMember.telephone
        holder.email.text = currentMember.email

        holder.telephone.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${currentMember.telephone}")
            }
            it.context.startActivity(intent)
        }

        holder.email.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${currentMember.email}")
            }
            it.context.startActivity(intent)
        }
    }

    override fun getItemCount() = memberList.size
}
