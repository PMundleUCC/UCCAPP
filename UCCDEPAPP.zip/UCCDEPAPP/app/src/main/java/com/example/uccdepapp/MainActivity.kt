package com.example.uccdepapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        val emailFab = findViewById<FloatingActionButton>(R.id.email_fab)



        // Initialize Firebase
        FirebaseDatabase.getInstance().setPersistenceEnabled(true)

        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_directory -> {
                    startActivity(Intent(this, DirectoryActivity::class.java))
                    true
                }
                R.id.nav_courses -> {
                    startActivity(Intent(this, CoursesActivity::class.java))
                    true
                }
                R.id.nav_timetable -> {
                    startActivity(Intent(this, TimetableActivity::class.java))
                    true
                }
                R.id.nav_admissions -> {
                    startActivity(Intent(this, AdmissionsActivity::class.java))
                    true
                }
                R.id.nav_social_media -> {
                    startActivity(Intent(this, SocialMediaActivity::class.java))
                    true
                }
                else -> false
            }
        }

        emailFab.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:hod@example.com")
                putExtra(Intent.EXTRA_SUBJECT, "Subject")
            }
            startActivity(intent)
        }
    }

// Click handler for Directory Button
fun onDirectoryButtonClick(view: android.view.View) {
    startActivity(Intent(this, DirectoryActivity::class.java))
}

// Click handler for Courses Button
fun onCoursesButtonClick(view: android.view.View) {
    startActivity(Intent(this, CoursesActivity::class.java))
}


    // Click handler for TimeTable Button
    fun onTimetableButtonClick(view: android.view.View) {
        startActivity(Intent(this, TimetableActivity::class.java))
    }

    // Click handler for Admissions Button
    fun onAdmissionsButtonClick(view: android.view.View) {
        startActivity(Intent(this, AdmissionsActivity::class.java))
    }



}
