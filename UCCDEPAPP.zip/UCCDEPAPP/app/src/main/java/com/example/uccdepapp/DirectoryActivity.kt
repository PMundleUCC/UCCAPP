package com.example.uccdepapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DirectoryActivity : ComponentActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var memberList: ArrayList<FacultyStaffMember>
    private lateinit var memberAdapter: FacultyStaffMemberAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_directory)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        memberList = ArrayList()
        memberAdapter = FacultyStaffMemberAdapter(memberList)
        recyclerView.adapter = memberAdapter

        database = FirebaseDatabase.getInstance().getReference("FacultyStaff")

        fetchFacultyStaff()
    }

    private fun fetchFacultyStaff() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                memberList.clear()
                for (memberSnapshot in snapshot.children) {
                    val member = memberSnapshot.getValue(FacultyStaffMember::class.java)
                    if (member != null) {
                        memberList.add(member)
                    }
                }
                memberAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Failed to load timetable data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
