package com.example.uccdepapp

data class Course(
    val code: String = "",
    val description: String = "",
    val credits: Int = 0,
    val name: String = "",
    val prerequisites: String = ""
)
