package com.example.uccdepapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import android.widget.Toast

class TimetableActivity : ComponentActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var database: FirebaseDatabase
    private lateinit var timetableRef: DatabaseReference
    private lateinit var timetableAdapter: TimetableAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance()
        timetableRef = database.getReference("Timetable")

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        timetableAdapter = TimetableAdapter()
        recyclerView.adapter = timetableAdapter

        // Load timetable data from Firebase
        loadTimetableData()
    }

    private fun loadTimetableData() {
        timetableRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val timetableList = mutableListOf<TimetableEntry>()
                for (childSnapshot in snapshot.children) {
                    val timetableEntry = childSnapshot.getValue(TimetableEntry::class.java)
                    timetableEntry?.let {
                        timetableList.add(it)
                    }
                }
                timetableAdapter.submitList(timetableList)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Failed to load timetable data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
