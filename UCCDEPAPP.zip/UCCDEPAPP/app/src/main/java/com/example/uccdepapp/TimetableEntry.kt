package com.example.uccdepapp

data class TimetableEntry(
    val year: Int = 0,
    val term: String = "",
    val classStartTime: String = "",
    val level: String ="",
    val course: String = "",
    val registrationPeriod: String = ""
)
