package com.example.uccdepapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CourseAdapter(private val courseList: List<Course>) :
    RecyclerView.Adapter<CourseAdapter.CourseViewHolder>() {

    class CourseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val courseCode: TextView = itemView.findViewById(R.id.course_code)
        val courseName: TextView = itemView.findViewById(R.id.course_name)
        val courseDescription: TextView = itemView.findViewById(R.id.course_description)
        val courseCredits: TextView = itemView.findViewById(R.id.course_credits)
        val coursePrerequisites: TextView = itemView.findViewById(R.id.course_prerequisites)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.course_item, parent, false)
        return CourseViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val currentCourse = courseList[position]
        holder.courseCode.text = currentCourse.code
        holder.courseName.text = currentCourse.name
        holder.courseDescription.text = currentCourse.description
        holder.courseCredits.text = currentCourse.credits.toString()
        holder.coursePrerequisites.text = currentCourse.prerequisites
    }

    override fun getItemCount() = courseList.size
}
