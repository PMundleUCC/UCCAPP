package com.example.uccdepapp

data class FacultyStaffMember(
    val name: String = "",
    val photoUrl: String = "",
    val telephone: String = "",
    val email: String = ""
)
