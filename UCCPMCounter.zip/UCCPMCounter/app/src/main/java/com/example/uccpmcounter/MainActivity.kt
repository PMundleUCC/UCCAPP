package com.example.uccpmcounter


import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Button
import android.widget.TextView

class MainActivity : ComponentActivity() {

    private lateinit var tvCounter: TextView
    private lateinit var btnIncrement: Button
    private lateinit var btnDecrement: Button
    private var counter: Int = 0
    private var maxcounter: Int=100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvCounter = findViewById(R.id.tvCounter)
        btnIncrement = findViewById(R.id.btnIncrement)
        btnDecrement = findViewById(R.id.btnDecrement)

        btnIncrement.setOnClickListener {
            if (counter < maxcounter) {
                counter++
                updateCounter()
            }
        }

        btnDecrement.setOnClickListener {
            if (counter > 0) {
                counter--
                updateCounter()
            }
        }

        updateCounter()
    }

    private fun updateCounter() {
        tvCounter.text = counter.toString()
        btnIncrement.isEnabled = counter < maxcounter
        btnDecrement.isEnabled = counter > 0
    }
}
